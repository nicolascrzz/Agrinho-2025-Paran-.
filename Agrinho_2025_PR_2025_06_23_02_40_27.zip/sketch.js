let img1, img2, img3, img4, img5, img6; // Fundos

let buttonImg1, buttonImg2, buttonImg3, buttonImg4, buttonImg6; // Botões

let fundoAtivo = 1; // Controle
let menu1 = true; //-
let menu2 = true; //-

let trees = [] // Árvores
let treeImgs = [] //-
let WaitTime = 180; //-
let LastTree = 0; //-
let podePlantar = true; //-
let tempoRestante = 0; //-
let TreeAnimation = []; //-
let maca = 0; //- 
let macaImg; //-
let MacaMin = 25; //-

let Carregando = false; // Carregamento
let CarregandoTemp = 0; //-

let TempStartTravel = 0; // Viagem

let caminhaoImg, caixaImg; // Minigame Escola
let caminhaoX = 400; //-
let caixaX = 9999; //-
let caixaY = 9999; //-
let arrastandoCaixa = false; //-
let caixaEntregue = false; //-
let caixaEntregues = 0; //-
let mensagemEntregaFrame = 0; //-
const posEntrega = { x: 45, y: 325, w: 125, h: 25 }; //-
let estadoCaminhao = "fora"; //-
let caixas = []; //-
let MaxCaixas = 5; //-
let podeEntregar = false; //-
let qtdCaixas = 0; //-
let caixaSelecionada = null; //-
let MGFinal = false; //-
// Variáveis

let pF = [
  { x: 20, y: 300},
  { x: 98, y: 315},
  { x: 165, y: 290},
  { x: 232, y: 311},
  { x: 300, y: 298}
];

let ttImg = []; // Tutorial
let ttPage = 0; //-
let ttMaxPage = 5; //-
let BtGo, BtBack, BtOut; //-
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

function preload() {
  // Contadores
  macaImg = loadImage("MolduraMaca.png")
  
  // Árvores
  treeImgs[0] = loadImage("Tree1.png");
  treeImgs[1] = loadImage("Tree2.png");
  treeImgs[2] = loadImage("Tree3.png");
  
  // Fundos
  img1 = loadImage("Fundo1.png");
  img2 = loadImage("Fundo2.png");
  img3 = loadImage("Fundo3.png");
  img4 = loadImage("Fundo4.png");
  img5 = loadImage("Fundo5.png");
  img6 = loadImage("Msg-Final.png");
  
  // Animação das Árvores
  for (let i = 0; i < 5; i++) {
    TreeAnimation[i] = loadImage("T" + (i+1) + ".png");
  }
  
  // Caminhão & Caixas
  caminhaoImg = loadImage("Truck.png");
  caixaImg = loadImage("Caixa.png");
  
  // Tutorial
  ttImg[0] = loadImage("tt0.png");
  ttImg[1] = loadImage("tt1.png");
  ttImg[2] = loadImage("tt2.png");
  ttImg[3] = loadImage("tt3.png");
  ttImg[4] = loadImage("tt4.png");
  ttImg[5] = loadImage("tt5.png");
  
  BtGo = loadImage("Bt-Go.png");
  BtBack = loadImage("Bt-Back.png");
  BtOut = loadImage("Bt-Out.png");
  }
// Pré-Carregar as imagens

function setup() {
  createCanvas(400, 400);
  // Função do Botão Menu 1
  button1();
  // Função do Botão de plantar
  button2();
  // Função do Botão de Aumentar a Velocidade 
  button3();
  // Função do Botão de Comprar
  button4();
  // Função do botão de voltar do minigame
  button6();
  // Criar botões do tutorial
  buttonsTT();
}
// Botões

function button1() {
  buttonImg1 = createImg("B-Jogar.png");
  buttonImg1.position(120, 130);
  buttonImg1.size(150, 50);
  buttonImg1.mousePressed(trocarFundo1);
  
  // Quando mouse passa por cima
  buttonImg1.mouseOver(() => {
    buttonImg1.size(152, 52);
    buttonImg1.position(118, 128);
  });
  
  buttonImg1.mouseOut(() => {
    buttonImg1.size(150, 50);
    buttonImg1.position(120, 130) ;
    });
}
// Botão Jogar

function button2() {
  buttonImg2 = createImg("B-Plantar.png");
  buttonImg2.position(13, 352)
  buttonImg2.size(123, 46);
  buttonImg2.mousePressed(() => {
    if (podePlantar) plantarArvore();
  })
  
  buttonImg2.mouseOver (() => {
    buttonImg2.size(124, 48);
    buttonImg2.position(13, 350);
  });
  
  buttonImg2.mouseOut(() => {
    buttonImg2.size(123, 46);
    buttonImg2.position(13, 352);
  });
}
// Botão Plantar

function button3() {
  buttonImg3 = createImg("B-Viajar.png");
  buttonImg3.position(262, 352);
  buttonImg3.size(120, 46);
  buttonImg3.mousePressed(() => {
    if (maca >= MacaMin) {
    fundoAtivo = 4;
    caminhaoX = 400;
      estadoCaminhao = "indo";
      podeEntregar = false;
      caixas = [];
      qtdCaixas = floor(maca / 5);
    let tempoDeViagem = random(3000, 6000);
    
    setTimeout(() => {
      fundoAtivo = 5;
      caixaEntregue = false;
      arrastandoCaixa = false;
      caixaX = 215;
      caixaY = 315;
    }, tempoDeViagem);
    } else {
      console.log("Você precisa colher pelo menos 25 maçãs para pode viajar!");
    }
  });
  
  buttonImg3.mouseOver(() => {
    buttonImg3.size(120, 49);
    buttonImg3.position(262, 350)
  });
  
  buttonImg3.mouseOut(() => {
    buttonImg3.size(120, 46);
    buttonImg3.position(262, 352);
  });
}
// Botão Melhorar

function button4() {
  buttonImg4 = createImg("B-Colher.png");
  buttonImg4.position(139,352);
  buttonImg4.size(120, 46);
  buttonImg4.mousePressed(colherFrutas);
  
  buttonImg4.mouseOver(() => {
    buttonImg4.size(120, 49);
    buttonImg4.position(139, 350);
  });
  
  buttonImg4.mouseOut(() => {
    buttonImg4.size(120, 46);
    buttonImg4.position(139, 352);
  })
}
// Botão Loja

function button6() {
  buttonImg6 = createImg('B-Voltar.png');
  buttonImg6.position(163, 140);
  buttonImg6.size(75, 40);
  buttonImg6.hide();
  
  buttonImg6.mousePressed(() => {
    fundoAtivo = 4;
    buttonImg6.hide();
    
    MGFinal = false;
    
    maca = 0;
    
    MacaMin += 5;
    
    setTimeout(() => {
      fundoAtivo = 3;
      menu2 = false
      
      for (let a of trees) {
        a.stage = 2;
        a.temMaca = true;
        a.recarregando = false;
      }
    }, random(2000, 3000));
  });
  
  buttonImg6.mouseOver(() => {
    buttonImg6.size(77, 42);
    buttonImg6.position(163, 140);
  });
  
  buttonImg6.mouseOut(() => {
    buttonImg6.size(75, 40);
    buttonImg6.position(163, 140);
  })
}
// botão Voltar

function buttonsTT() {
  BtGo = createImg("Bt-Go.png");
  BtGo.position(295, 150);
  BtGo.size(40, 40);
  BtGo.mousePressed(() => {
    if (ttPage < ttMaxPage) {
      ttPage++;
    }
  });
  
  BtBack = createImg("Bt-Back.png");
  BtBack.position(68, 150);
  BtBack.size(40, 40);
  BtBack.mousePressed(() => {
    if (ttPage > 0) {
      ttPage--;
    }
  });
  
  BtOut = createImg("Bt-Out.png");
  BtOut.position(150, 275);
  BtOut.size(100, 40);
  BtOut.mousePressed(() => {
    fundoAtivo = 3;
    BtGo.hide();
    BtBack.hide();
    BtOut.hide();
  });
  
  BtGo.hide();
  BtBack.hide();
  BtOut.hide();
}
// Botões do Tutorial

function colherFrutas() {
  let colhidas = 0
  
  for (let a of trees) {
    if (a.stage === 2 && a.temMaca) {
      a.temMaca = false;
      a.recarregando = true;
      a.recStage = 0;
      a.recStart = frameCount
      maca++;
      colhidas++;
    }
  }
  
  if (colhidas > 0) {
    console.log(`Você colheu ${colhidas} maçã(s)! Total: ${maca}`)
  } else {
    console.log("nenhuma maçã para colher!")
  }
}

function trocarFundo1() {
  fundoAtivo = 2;
  menu1 = false;
}
// Trocar o fundo 1 para o 2

function trocarFundo2() {
  fundoAtivo = 3;
  menu2 = false;
}
// Trocar o Fundo 2 para o 3

function plantarArvore() {
  if (trees.length > 0 && frameCount - LastTree < WaitTime) {
    console.log("Quanta pressa! Haha... espere um pouquinho!")
    return;
  }
  
  if (trees.length >= pF.length) {
    console.log("Limite Excedido!");
    return;
  }
  
  let pos = pF[trees.length];
  trees.push({ 
    x: pos.x, 
    y: pos.y, 
    stage: 0, 
    inicio: frameCount, 
    temMaca: false,
    recarregando: false,
    recStage: 0,
    recStart: 0
  });
  
  LastTree = frameCount;
  tempoRestante = WaitTime;
  podePlantar = false;
  buttonImg2.elt.src = "C-3.png"; // Inicia contagem visual
  console.log("Árvore Plantada com Sucesso!!");
}  
// Plantar árvores

function draw() {
  if (buttonImg1) {
  if (fundoAtivo === 1 && menu1) {
    buttonImg1.show();
  } else {
    buttonImg1.hide();
  }
}
  
  //Função tutorial
  if (fundoAtivo === 2) {
    background(img2);
    
    image(ttImg[ttPage], 0, 0, width, height);
    
    if (ttPage === 0) {
      BtBack.hide();
      BtGo.show();
      BtOut.hide();
    } else if (ttPage === ttMaxPage) {
      BtBack.show();
      BtGo.hide();
      BtOut.show();
    } else {
      BtBack.show();
      BtGo.show();
      BtOut.hide();
    }
    
    return;
  }
  if (fundoAtivo !== 2) {
    BtBack.hide();
    BtGo.hide();
    BtOut.hide();
  }
  //função bg
  bg();
  //função tree
  tree();
  //Sair do menu 1
  aparecerNoMenu1();
  //Mostrar botões depois do menu
  aparecerNoJogo1();
  //Animação do botão
  UpdateButtonPlant();
  //Contador de Maçãs
  if (fundoAtivo === 3) {
    MostrarMacas();
  }
  if (fundoAtivo === 5) {
    mostrarEntrega();
  }
  
  if (MGFinal) {
  image(img6, 0, 0, 400, 400); // Agora a imagem vai ficar aparecendo de verdade
  buttonImg6.show();          // Mostra o botão "Voltar"
  return;                     // Para o resto do draw, evitando bugs visuais
}
}
// Funções secundárias

function mostrarEntrega() {
  //movimentar caminhão
 if (estadoCaminhao === "indo") {
   if (caminhaoX > 200) {
     caminhaoX -= 2;
   } else {
     estadoCaminhao = "parado";
     setTimeout(() => {
       for (let i = 0; i < qtdCaixas; i++) {
         caixas.push({ x: 200 + i * 40, y: 295, entregue: false});
       }
       estadoCaminhao = "saindo";
     }, 2000);
   }
 } else if (estadoCaminhao === 'saindo') {
   if (caminhaoX < 410) {
     caminhaoX += 2;
   } else {
     estadoCaminhao = "fora";
     podeEntregar = true;
     maca -= qtdCaixas * 5
   }
 }
  
  if (estadoCaminhao !== "fora") {
    image(caminhaoImg, caminhaoX, 260, 205, 115);
  }
  
  if (podeEntregar) {
    let visiveis = caixas.filter(c => !c.entregue).slice(0, 5);
    
    for (let caixa of visiveis) {
      if (!caixa.entregue) {
        if (!arrastandoCaixa || caixa !== caixaSelecionada) {
          image(caixaImg, caixa.x, caixa.y, 40, 40);
        } else {
          image(caixaImg, mouseX - 20, mouseY - 20, 40, 40)
        }
      }
    }
  noFill();
  stroke(255)
  rect(posEntrega.x, posEntrega.y, posEntrega.w, posEntrega.h);
    
    if (frameCount - mensagemEntregaFrame < 120) {
      fill(0);
      textSize(20);
      textAlign(CENTER, CENTER);
      text("+🍎", width / 2, height / 2 )
    }
  }
  let todasEntregues = caixas.every(caixa => caixa.entregue);
  
  if (todasEntregues && estadoCaminhao === "fora" && !MGFinal) {
    MGFinal = true;
    setTimeout(() => {
      image(img6, 0, 0, 400, 400);
      buttonImg6.show();
    }, 100);
  }
}
// Entregar Maçãs

function MostrarMacas() {
  let x = 300;
  let y = 0;
  let w = 100;
  let h = 50; 
  
  image(macaImg, x, y, w, h);
  
  fill(0);
  textAlign(CENTER, CENTER)
  textSize(20);
  text(maca, x + 75 / 2, y + 59 / 2)
}
// Mostrar Maçãs

function UpdateButtonPlant() {
  if (trees.length >= pF.length) {
  buttonImg2.elt.src = "B-Plantar.png";  // volta para a imagem padrão
  podePlantar = false;                   // opcional: bloqueia plantar se quiser
  return;
}
  
  if (!podePlantar) {
    tempoRestante--;
    
    let segundos = Math.ceil(tempoRestante / 60);
    
    if (segundos >= 3) {
      buttonImg2.elt.src = "C-3.png"
    } else if (segundos == 2) {
      buttonImg2.elt.src = "C-2.png"
    } else if (segundos == 1) {
      buttonImg2.elt.src = "C-1.png"
    }
    
    if (tempoRestante <= 0) {
      podePlantar = true;
      buttonImg2.elt.src = "B-Plantar.png"
    }
  }
}
// Animação do B-Plant

function aparecerNoMenu1() {
  if (menu1 && fundoAtivo === 1) {
    buttonImg1.show();
  } else {
    buttonImg1.hide();
   
  }
}
// Esconder/ Mostrar botões

function aparecerNoJogo1() {
  if (fundoAtivo === 3) {
    // Mostra os botões quando estiver no jogo
    buttonImg2.show();  // Plantar
    buttonImg3.show();  // Viajar
    buttonImg4.show();  // Colher
    buttonImg6.hide();  // Voltar escondido
  } else {
    // Esconde todos quando não estiver no jogo
    buttonImg2.hide();
    buttonImg3.hide();
    buttonImg4.hide();
    buttonImg6.hide();
  }
}
// Esconder/ Mostrar botões

function bg() {
  if (fundoAtivo === 1) {
    background(img1);
  } else  if (fundoAtivo === 2) {
    background(img2);
  } else if (fundoAtivo === 3) {
    background(img3);
  } else if (fundoAtivo === 4) {
    background(img4);
  } else if (fundoAtivo === 5) {
    background(img5);
  }

}
// Background do Game

function tree() {
  if (fundoAtivo !== 3) return; // Árvores aparecem apenas no jogo 1
  
  let tH = [75, 85, 100];
  let tW = [80, 80, 80];
  
  let camadas = trees.slice().sort((a, b) => a.y - b.y);
  
  for (let a of trees) {
    if (frameCount - a.inicio > 360 && a.stage < 2) {
      a.stage++;
      a.inicio = frameCount;
      
      if (a.stage === 2) {
        a.temMaca = true;
      }
      
    }
    let h = tH[a.stage];
    let w = tW[a.stage];
    
    if (a.stage === 2 && a.recarregando) {
      let intervalo = 60;
      
      if (frameCount - a.recStart > intervalo) {
        a.recStage++;
        a.recStart = frameCount;
      }
      
      if (a.recStage >= TreeAnimation.length) {
        a.recarregando = false;
        a.temMaca = true;
      } else {
        image(TreeAnimation[a.recStage], a.x, a.y - h, w, h);
        continue;
      }
    }
    
    image(treeImgs[a.stage], a.x, a.y - h, w, h);
  }
}
// Fases do plantío

function mousePressed() {
  if (fundoAtivo === 5 && podeEntregar) {
    let visiveis = caixas.filter(c => !c.entregue).slice(0, 5);
    for (let caixa of caixas) {
      if (!caixa.entregue && dist(mouseX, mouseY, caixa.x + 20, caixa.y + 20) < 25) {
        caixaSelecionada = caixa;
        arrastandoCaixa = true;
        break;
      }
    }
  }
}
// Função de arrastar as caixas.

function mouseReleased() {
  if (arrastandoCaixa) {
    if (
      mouseX > posEntrega.x &&
      mouseX < posEntrega.x + posEntrega.w &&
      mouseY > posEntrega.y &&
      mouseY < posEntrega.y + posEntrega.h
    ) {
      caixaSelecionada.entregue = true;
      caixaEntregues++;
      mensagemEntregaFrame = frameCount;
      caixaSelecionada = null;
    }
    arrastandoCaixa = false;
  }
  //console.log(mouseX, mouseY)
}
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

//Construído por @nicolas.crzz | Nicolas Andreotti - 1º Do Ensino Médio integrado.